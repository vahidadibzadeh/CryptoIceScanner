
package com.cryptoice.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

public class ScanService extends Service {

    private static final String CHANNEL_ID = "scan_channel";
    private static final int NOTIF_ID = 1001;

    private ExecutorService executor;
    private Handler mainHandler;
    private AtomicBoolean running = new AtomicBoolean(false);
    private AtomicInteger checked = new AtomicInteger(0);

    private List<String> wordlist = new ArrayList<>();
    private Set<String> keywordSet = new HashSet<>();
    private Random random = new Random();

    private static volatile boolean sRunning = false;
    public static boolean isRunning() { return sRunning; }

    @Override
    public void onCreate() {
        super.onCreate();
        mainHandler = new Handler(Looper.getMainLooper());
        executor = Executors.newSingleThreadExecutor();
        loadWords();
        loadKeywords();
        startInForeground();
    }

    private void loadWords() {
        try {
            InputStream is = getAssets().open("bip39_english.txt");
            BufferedReader br = new BufferedReader(new InputStreamReader(is));
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty() || line.startsWith("#")) continue;
                wordlist.add(line);
            }
            br.close();
        } catch (Exception e) {
            // fallback small list
            String[] demo = new String[]{"abandon","ability","able","about","above","absent","absorb","abstract","absurd","abuse"};
            for (String s : demo) wordlist.add(s);
        }
    }

    private void loadKeywords() {
        String csv = getSharedPreferences("WalletScanPrefs", MODE_PRIVATE).getString("keywords_csv", "");
        keywordSet.clear();
        if (csv == null) return;
        for (String w : csv.split(",")) {
            String t = w.trim().toLowerCase();
            if (!t.isEmpty()) keywordSet.add(t);
        }
    }

    private void startInForeground() {
        createNotificationChannel();
        Intent stopIntent = new Intent(this, ScanService.class);
        stopIntent.setAction("STOP");
        PendingIntent pStop = PendingIntent.getService(this, 1, stopIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));

        Intent openIntent = new Intent(this, MainActivity.class);
        PendingIntent pOpen = PendingIntent.getActivity(this, 0, openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));

        Notification notif = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle(getString(R.string.notif_title))
                .setSmallIcon(R.drawable.ic_launcher_foreground)
                .setContentIntent(pOpen)
                .addAction(0, getString(R.string.notif_action_stop), pStop)
                .setOngoing(true)
                .build();

        startForeground(NOTIF_ID, notif);
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID,
                    getString(R.string.notif_channel_name),
                    NotificationManager.IMPORTANCE_LOW);
            channel.setDescription(getString(R.string.notif_channel_desc));
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            nm.createNotificationChannel(channel);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && "STOP".equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (!running.get()) {
            running.set(true);
            sRunning = true;
            Broadcasts.sendState(this, true);
            executor.execute(this::scanLoop);
        }
        return START_STICKY;
    }

    private void scanLoop() {
        PowerManager.WakeLock wl = null;
        try {
            // Light wakelock to keep CPU on during active scan bursts
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (pm != null) {
                wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "CryptoIce:Scan");
                wl.setReferenceCounted(false);
                wl.acquire(10 * 60 * 1000L); // 10 min safety
            }

            while (running.get()) {
                int c = checked.incrementAndGet();
                String mnemonic = generateMnemonic(12);
                String line = "Wallet #" + c + ": " + mnemonic;

                // Chance to find a wallet
                boolean found = (c >= 1000) || (c > 100 && random.nextInt(1000) == 1);
                if (found) {
                    double amount = 0.001 + (random.nextDouble() * 0.009);
                    String formatted = String.format(java.util.Locale.US, "%.8f", amount);
                    saveLast(mnemonic, formatted);
                    Broadcasts.sendFound(this, mnemonic, formatted);
                    // After found, we keep running unless user stops; break if you want auto-stop
                    // running.set(false);
                }

                Broadcasts.sendTick(this, c, line);

                // Adaptive sleep for battery – short when active, longer over time
                long delay = 120 + (c % 50 == 0 ? 200 : 0);
                try { Thread.sleep(delay); } catch (InterruptedException ignored) {}
            }
        } finally {
            if (wl != null && wl.isHeld()) wl.release();
            sRunning = false;
            Broadcasts.sendState(this, false);
            stopForeground(true);
            stopSelf();
        }
    }

    private void saveLast(String words, String amount) {
        getSharedPreferences("WalletScanPrefs", MODE_PRIVATE)
                .edit()
                .putString("last_words", words)
                .putString("last_amount", amount)
                .apply();
    }

    private String generateMnemonic(int n) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < n; i++) {
            if (i > 0) sb.append(' ');
            String w = pickWordBiased();
            sb.append(w);
        }
        return sb.toString();
    }

    private String pickWordBiased() {
        // 70% normal, 30% biased to keywords if any
        boolean useBias = !keywordSet.isEmpty() && random.nextInt(100) < 30;
        if (useBias) {
            // try to pick from keywords that exist in wordlist
            // fall back if none match
            List<String> matches = new ArrayList<>();
            for (String w : wordlist) {
                if (keywordSet.contains(w)) matches.add(w);
            }
            if (!matches.isEmpty()) {
                return matches.get(random.nextInt(matches.size()));
            }
        }
        return wordlist.get(random.nextInt(wordlist.size()));
    }

    @Override
    public void onDestroy() {
        running.set(false);
        if (executor != null) executor.shutdownNow();
        super.onDestroy();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) { return null; }
}
