
package com.cryptoice.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;

public class Broadcasts {

    public static final String ACTION_TICK = "com.cryptoice.app.TICK";
    public static final String ACTION_FOUND = "com.cryptoice.app.FOUND";
    public static final String ACTION_STATE = "com.cryptoice.app.STATE";

    public static final String EXTRA_CHECKED = "checked";
    public static final String EXTRA_LINE = "line";
    public static final String EXTRA_MNEMONIC = "mnemonic";
    public static final String EXTRA_AMOUNT = "amount";
    public static final String EXTRA_RUNNING = "running";

    public interface Receiver {
        void onScanTick(int checked, String lastLine);
        void onFound(String mnemonic, String amount);
        void onState(boolean running);
    }

    public static void sendTick(Context c, int checked, String lastLine) {
        Intent i = new Intent(ACTION_TICK);
        i.putExtra(EXTRA_CHECKED, checked);
        i.putExtra(EXTRA_LINE, lastLine);
        c.sendBroadcast(i);
    }

    public static void sendFound(Context c, String mnemonic, String amount) {
        Intent i = new Intent(ACTION_FOUND);
        i.putExtra(EXTRA_MNEMONIC, mnemonic);
        i.putExtra(EXTRA_AMOUNT, amount);
        c.sendBroadcast(i);
    }

    public static void sendState(Context c, boolean running) {
        Intent i = new Intent(ACTION_STATE);
        i.putExtra(EXTRA_RUNNING, running);
        c.sendBroadcast(i);
    }

    public static void register(Context c, Receiver r) {
        IntentFilter f = new IntentFilter();
        f.addAction(ACTION_TICK);
        f.addAction(ACTION_FOUND);
        f.addAction(ACTION_STATE);
        c.registerReceiver(new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String a = intent.getAction();
                if (ACTION_TICK.equals(a)) {
                    r.onScanTick(intent.getIntExtra(EXTRA_CHECKED, 0), intent.getStringExtra(EXTRA_LINE));
                } else if (ACTION_FOUND.equals(a)) {
                    r.onFound(intent.getStringExtra(EXTRA_MNEMONIC), intent.getStringExtra(EXTRA_AMOUNT));
                } else if (ACTION_STATE.equals(a)) {
                    r.onState(intent.getBooleanExtra(EXTRA_RUNNING, false));
                }
            }
        }, f);
    }

    public static void unregister(Context c, Receiver r) {
        try {
            c.unregisterReceiver((BroadcastReceiver) r);
        } catch (Exception ignore) {}
    }
}
