
package com.cryptoice.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

public class StartupReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        // Optionally auto-restart after boot based on a flag (disabled by default)
        SharedPreferences prefs = context.getSharedPreferences("WalletScanPrefs", Context.MODE_PRIVATE);
        boolean autoStart = prefs.getBoolean("auto_start_on_boot", false);
        if (autoStart) {
            Intent i = new Intent(context, ScanService.class);
            context.startForegroundService(i);
        }
    }
}
