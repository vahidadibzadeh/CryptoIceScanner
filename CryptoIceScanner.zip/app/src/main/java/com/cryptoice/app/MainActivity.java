
package com.cryptoice.app;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private TextView checkedTextView;
    private TextView scanResultsTextView;
    private TextView foundAmountTextView;
    private TextView foundWordsTextView;
    private ImageView foundLogoImageView;
    private Button startButton;
    private Button stopButton;
    private Button supportButton;
    private Button whitelistButton;
    private Button keywordsButton;

    private SharedPreferences prefs;

    private final Broadcasts.Receiver receiver = new Broadcasts.Receiver() {
        @Override
        public void onScanTick(int checked, String lastLine) {
            checkedTextView.setText(getString(R.string.checked_text, checked));
            if (lastLine != null && !lastLine.isEmpty()) {
                scanResultsTextView.append(lastLine + "\n");
            }
        }

        @Override
        public void onFound(String mnemonic, String amount) {
            foundWordsTextView.setText(mnemonic);
            foundAmountTextView.setText(amount + " BTC");
            foundLogoImageView.setVisibility(View.VISIBLE);
            showWalletFoundDialog(mnemonic, amount);
        }

        @Override
        public void onState(boolean running) {
            startButton.setEnabled(!running);
            stopButton.setEnabled(running);
        }
    };

    private final ActivityResultLauncher<Intent> batteryOptLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                // No-op, user decides
            });

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences("WalletScanPrefs", MODE_PRIVATE);

        checkedTextView = findViewById(R.id.checkedTextView);
        scanResultsTextView = findViewById(R.id.scanResultsTextView);
        foundAmountTextView = findViewById(R.id.foundAmountTextView);
        foundWordsTextView = findViewById(R.id.foundWordsTextView);
        foundLogoImageView = findViewById(R.id.foundLogoImageView);
        startButton = findViewById(R.id.startButton);
        stopButton = findViewById(R.id.stopButton);
        supportButton = findViewById(R.id.supportButton);
        whitelistButton = findViewById(R.id.whitelistButton);
        keywordsButton = findViewById(R.id.keywordsButton);

        Broadcasts.register(this, receiver);

        loadLastResult();
        updateButtons(ScanService.isRunning());

        startButton.setOnClickListener(v -> startService());
        stopButton.setOnClickListener(v -> stopService());
        supportButton.setOnClickListener(v -> openSupport());
        whitelistButton.setOnClickListener(v -> requestBatteryWhitelist());
        keywordsButton.setOnClickListener(v -> openKeywordsDialog());
    }

    private void updateButtons(boolean running) {
        startButton.setEnabled(!running);
        stopButton.setEnabled(running);
    }

    private void startService() {
        Intent i = new Intent(this, ScanService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(i);
        } else {
            startService(i);
        }
        Toast.makeText(this, getString(R.string.scan_started), Toast.LENGTH_SHORT).show();
    }

    private void stopService() {
        Intent i = new Intent(this, ScanService.class);
        stopService(i);
        Toast.makeText(this, getString(R.string.scan_stopped), Toast.LENGTH_SHORT).show();
    }

    private void openSupport() {
        Intent intent = new Intent(Intent.ACTION_SENDTO);
        intent.setData(Uri.parse("mailto:" + getString(R.string.contact_email)));
        intent.putExtra(Intent.EXTRA_SUBJECT, "BIP-39 Support Request");
        intent.putExtra(Intent.EXTRA_TEXT, getString(R.string.support_message));
        try {
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "Email app not found", Toast.LENGTH_SHORT).show();
        }
    }

    private void showWalletFoundDialog(String words, String amount) {
        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.dialog_found_title))
                .setMessage("Mnemonic:\n" + words + "\n\nBalance: " + amount + " BTC")
                .setPositiveButton(getString(R.string.dialog_found_ok), (dialog, which) -> dialog.dismiss())
                .show();
    }

    private void requestBatteryWhitelist() {
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        if (pm != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            String pkg = getPackageName();
            if (!pm.isIgnoringBatteryOptimizations(pkg)) {
                Intent intent = new Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                intent.setData(Uri.parse("package:" + pkg));
                batteryOptLauncher.launch(intent);
            } else {
                Toast.makeText(this, "Already whitelisted", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void openKeywordsDialog() {
        String current = prefs.getString("keywords_csv", "");
        final android.widget.EditText input = new android.widget.EditText(this);
        input.setText(current);
        input.setHint("e.g. apple, banana, hotel");

        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.dialog_keywords_title))
                .setMessage(getString(R.string.dialog_keywords_msg))
                .setView(input)
                .setPositiveButton(getString(R.string.dialog_save), (d, w) -> {
                    prefs.edit().putString("keywords_csv", input.getText().toString()).apply();
                    Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton(getString(R.string.dialog_cancel), null)
                .show();
    }

    private void loadLastResult() {
        String lastWords = prefs.getString("last_words", null);
        String lastAmount = prefs.getString("last_amount", null);
        if (lastWords != null && lastAmount != null) {
            foundWordsTextView.setText(lastWords);
            foundAmountTextView.setText(lastAmount + " BTC");
            foundLogoImageView.setVisibility(View.VISIBLE);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Broadcasts.unregister(this, receiver);
    }
}
